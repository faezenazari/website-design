let logoElm = document.getElementById("navbar-brand")
function clickFunc(){
 logoElm.style.color = "crimson"
}

let nameInput = document.querySelector('.form-control')
let messageInput = document.querySelector('.form-control')
let modal = document.querySelector('.modal')


 function dataValidation(){
  let nameValue = nameInput.value
  let messageValue = messageInput.value
  if (nameValue.length < 8 || messageValue.length < 12){
   alert("no")
  }else{
   alert("yes")
  }

 console.log(nameValue,messageValue)
 }